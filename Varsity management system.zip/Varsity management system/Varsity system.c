#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<process.h>
#include<stdlib.h>
#include<dos.h>
struct student
{
    char name[100];
    char sub[100];
    char grade[100];
    float cgpa;
    char id[100];
    int credit;
    float mark;
};


struct teacherinfo
{

char name[20],ph[20],dept[20],email[30];
}list;

char query[20],name[20];
FILE *fp, *ft;

int i,n,ch,l,found;

int main()
{


FILE *fpi;

main:
system("cls");    /* ************Main menu ***********************  */
printf("\n\t **** Welcome to varsity system ****");
printf("\n\n\n\t\t\tMAIN MENU\n\t\t=====================\n\t\t[1] Add a new teacher info\n\t\t[2] List all teacher info\n\t\t[3] Search for teacher info\n\t\t[4] Edit a teacher info\n\t\t[5] Delete a teacher info\n\t\t[6] Result calculate\n\t\t[7] Waiver calculate\n\t\t[8] Payment layout\n\t\t[0] Exit\n\t\t=================\n\t\t");
printf("Enter the choice:");
scanf("%d",&ch);

switch(ch)
{
case 0:
printf("\n\n\t\tAre you sure u want to exit?");
break;
/* *********************add new teacher info************  */
case 1:

system("cls");
fpi=fopen("Information.txt","a");
fp=fopen("Teacherinfo.txt","a");
for (;;)
{ fflush(stdin);
printf("To exit enter blank space in the name input\nName (Use identical):");
scanf("%[^\n]",&list.name);
fprintf(fpi,"%s\n",list.name);
if(stricmp(list.name,"")==0 || stricmp(list.name," ")==0)
break;
fflush(stdin);
printf("Phone:");
scanf("%s",&list.ph);
fprintf(fpi,"Phone: %s\n",list.ph);
fflush(stdin);
printf("Department & Address:");
scanf("%[^\n]",&list.dept);
fprintf(fpi,"Department & Address: %s\n",list.dept);
fflush(stdin);
printf("email address:");
gets(list.email);
fprintf(fpi,"Email address: %s\n\n",list.email);
printf("\n");
fwrite(&list,sizeof(list),1,fp);
}
fclose(fp);
fclose(fpi);
break;

/* *********************list of teacher info*************************  */
case 2:
system("cls");
printf("\n\t\t================================\n\t\t\tLIST OF TEACHER INFO\n\t\t================================\n\nName\t\tPhone No\t    Department/Address\t\tE-mail ad.\n=================================================================\n\n");

for(i=97;i<=122;i=i+1)
{


fp=fopen("Teacherinfo.txt","r");
fflush(stdin);
found=0;
while(fread(&list,sizeof(list),1,fp)==1)
{
if(list.name[0]==i || list.name[0]==i-32)
{
printf("\nName\t: %s\nPhone\t: %s\nDepartment & Address\t: %s\nEmail\t: %s\n",list.name,list.ph,list.dept,list.email);
found++;

}
}
if(found!=0)
{printf("=========================================================== [%c]-(%d)\n\n",i-32,found);
getch();}
fclose(fp);

}

break;



/* *******************search teacher info**********************  */
case 3:
system("cls");
do
{
found=0;
printf("\n\n\t..::TEACHER INFO SEARCH\n\t===========================\n\t..::Name of Teacher to search: ");
fflush(stdin);
scanf("%[^\n]",&query);
l=strlen(query);
fp=fopen("Teacherinfo.txt","r");

system("cls");
printf("\n\n..::Search result for '%s' \n===================================================\n",query);
while(fread(&list,sizeof(list),1,fp)==1)
{
for(i=0;i<=l;i++)
name[i]=list.name[i];
name[l]='\0';
if(stricmp(name,query)==0)
{
printf("\n..::Name\t: %s\n..::Phone\t: %s\n..::Department & Address\t: %s\n..::Email\t:%s\n",list.name,list.ph,list.dept,list.email);
found++;
if (found%4==0)
{
printf("..::Press any key to continue...");
getch();
}
}
}

if(found==0)
printf("\n..::No match found!");
else
printf("\n..::%d match(s) found!",found);
fclose(fp);
printf("\n ..::Try again?\n\n\t[1] Yes\t\t[0] No\n\t");
scanf("%d",&ch);
}while(ch==1);
break;


/* *********************edit teacher info************************/
case 4:
system("cls");
fp=fopen("Teacherinfo.txt","r");
ft=fopen("temp.dat","a");
fflush(stdin);
printf("..::Edit teacher info\n===============================\n\n\t..::Enter the name of teacher info to edit:");
scanf("%[^\n]",name);
while(fread(&list,sizeof(list),1,fp)==1)
{
if(stricmp(name,list.name)!=0)
fwrite(&list,sizeof(list),1,ft);
}
fflush(stdin);
printf("\n\n..::Editing '%s'\n\n",name);
printf("..::Name(Use identical):");
scanf("%[^\n]",&list.name);
fflush(stdin);
printf("..::Phone:");
scanf("%s",&list.ph);
fflush(stdin);
printf("..::department & Address:");
scanf("%[^\n]",&list.dept);
fflush(stdin);
printf("..::email address:");
gets(list.email);
printf("\n");
fwrite(&list,sizeof(list),1,ft);
fclose(fp);
fclose(ft);
remove("Teacherinfo.txt");
rename("temp.dat","Teacherinfo.txt");
break;


/* ********************delete teacher info**********************/
case 5:
system("cls");
fflush(stdin);
printf("\n\n\t..::DELETE A TEACHER INFO\n\t==========================\n\t..::Enter the name of Teacher to delete:");
scanf("%[^\n]",&name);
fp=fopen("Teacherinfo.txt","r");
ft=fopen("temp.dat","a");
while(fread(&list,sizeof(list),1,fp)!=0)
if (stricmp(name,list.name)!=0)
fwrite(&list,sizeof(list),1,ft);
fclose(fp);
fclose(ft);
remove("Teacherinfo.txt");
rename("temp.dat","Teacherinfo.txt");
break;
case 6:
    system("cls");
    result();
    break;
case 7:
    system("cls");
    waiver();
    break;
case 8:
    system("cls");
    payment();
    break;

default:
printf("Invalid choice");
break;
}


printf("\n\n\n..::Enter the Choice:\n\n\t[1] Main Menu\t\t[0] Exit\n");
scanf("%d",&ch);
switch (ch)
{
case 1:
goto main;


case 0:
break;

default:
printf("Invalid choice");
break;
}

return 0;
}
 result()
{
    FILE *fpr;
     fpr=fopen("Result.txt","a");
    struct student c[100];
    int i,a,allcredit[100];
    float allmark[100],gpa;
    char result[100];
    printf("Press '1' for Login the system: ");
    scanf("%d",&a);
    for(i=0;i<a;i++)
    {
        printf("\n\nEnter student name(use underscore'_'): ");
        scanf("%s",c[i].name);
        printf("\nEnter student id : ");
        scanf("%s",c[i].id);
        printf("\nEnter student 1st subject name & mark & credit: ");
        scanf("%s %f %d",c[i].sub,&c[i].mark,&c[i].credit);
        printf("\nEnter student 2nd subject name & mark & credit: ");
        scanf("%s %f %d",c[i+1].sub,&c[i+1].mark,&c[i+1].credit);
        printf("\nEnter student 3rd subject name & mark & credit: ");
        scanf("%s %f %d",c[i+2].sub,&c[i+2].mark,&c[i+2].credit);
        printf("\nEnter student 4th subject name & mark & credit: ");
        scanf("%s %f %d",c[i+3].sub,&c[i+3].mark,&c[i+3].credit);
        allmark[i]=c[i].mark+c[i+1].mark+c[i+2].mark+c[i+3].mark;
        allcredit[i]=c[i].credit+c[i+1].credit+c[i+2].credit+c[i+3].credit;
    }
    for(i=0;i<a;i++)
    {
        if(allmark[i]/4>=80)
        {
            strcpy(result,"A+");
            gpa=4.00;
        }
        else if(allmark[i]/4>=75)
        {
            strcpy(result,"A");
            gpa=3.75;
        }
        else if(allmark[i]/4>=70)
        {
            strcpy(result,"A-");
            gpa=3.50;
        }
        else if(allmark[i]/4>=65)
        {
            strcpy(result,"B+");
            gpa=3.25;
        }
        else if(allmark[i]/4>=60)
        {
            strcpy(result,"B");
            gpa=3.00;
        }
        else if(allmark[i]/4>=55)
        {
            strcpy(result,"B-");
            gpa=2.75;
        }
        else if(allmark[i]/4>=50)
        {
            strcpy(result,"C+");
            gpa=2.50;
        }
        else if(allmark[i]/4>=45)
        {
            strcpy(result,"C");
            gpa=2.25;
        }
        else if(allmark[i]/4>=40)
        {
            strcpy(result,"D");
            gpa=2.00;
        }
        else
        {
            strcpy(result,"F");
            gpa=0.00;
        }
        printf("\n\nstudent name: %s",c[i].name);
        fprintf(fpr,"\n\nstudent name: %s",c[i].name);
        printf("\n student ID: %s",c[i].id);
        fprintf(fpr,"\n student ID: %s",c[i].id);
        printf("\n\nstudent Subject: \n%s:%.2f\n%s:%.2f\n%s:%.2f\n%s:%.2f",c[i].sub,c[i].mark,c[i+1].sub,c[i+1].mark,c[i+2].sub,c[i+2].mark,c[i+3].sub,c[i+3].mark);
        fprintf(fpr,"\n\n student Subject: \n%s:%.2f\n%s:%.2f\n%s:%.2f\n%s:%.2f",c[i].sub,c[i].mark,c[i+1].sub,c[i+1].mark,c[i+2].sub,c[i+2].mark,c[i+3].sub,c[i+3].mark);
        printf("\n\nstudent All Credit: %d",allcredit[i]);
        fprintf(fpr,"\n\nstudent All Credit: %d",allcredit[i]);
        printf("\nstudent Result: %s",result);
        fprintf(fpr,"\nstudent Result: %s",result);
        printf("\nstudent SGPA: %.2f\n\n",gpa);
        fprintf(fpr,"\nstudent SGPA: %.2f\n\n",gpa);
        fclose(fpr);

    }
}

waiver()
{
	int i;
	float cgpa, semester_fee, total_payment;
	char student_name[40];
	char student_id[10];
	char semester_name[20];

	printf("Enter student name (use underscore'_'): ");
	scanf("%s", student_name);

	printf("Enter student ID: ");
	scanf("%s", student_id);

	printf("Enter student Semester: ");
	scanf("%s", semester_name);

	    printf("Enter Total payment: ");
	    scanf("%f", &total_payment);

		printf("\nPlease,enter CGPA for Student: ",i);
		scanf("%f", &cgpa);
		if (cgpa < 3)
			semester_fee = total_payment;
		else if (cgpa >= 3 && cgpa < 3.5)
			semester_fee = total_payment * 0.9;
		else if (cgpa >= 3.5 && cgpa < 3.80)
			semester_fee = total_payment * 0.7;
		else
			semester_fee = total_payment * 0.5;
		printf("\nYour semester fee is:%.2f\n\n", semester_fee);
}

payment ()
{
        FILE *fpp;
        fpp=fopen("Payment.txt","a");
        if(fpp==NULL)
    {
        printf("\n\terror\n");
    }
    struct info
    {
        char name[200],id[10];
        float credit,receivable,paid,due;
        int waiver;
    };

    int j=0,k;
    float total=0,credit=0;




    int char_count;
    struct info details;




        printf("Enter name of student(use underscore'_'): ");

        scanf("%s",details.name);
        printf("Enter your ID: ");
        scanf("%s",details.id);


        printf("Credit Rate = 3000 taka\n");

        printf("Enter total credits : ");
        scanf("%f",&details.credit);


        printf("Enter the waiver (%%) :");
        scanf("%d",&details.waiver);

         details.receivable=(3000*details.credit);
        details.receivable = details.receivable*(100-details.waiver)/100;
        details.receivable = details.receivable + 12500;

        printf("Receivable :%.2f\n",details.receivable);


        printf("Enter the paid amount:");

        scanf("%f",&details.paid);

        details.due =details.receivable - details.paid;

    system("cls");
    printf("Name      Total credit    Paid     receivable     Due \n");
    fprintf(fpp,"Name      Total credit    Paid     receivable     Due \n");


            printf(" ");
            fprintf(fpp," ");

        printf("%s         %.2f      %.2f    %.2f     %.2f\n",details.name,details.credit,details.paid,details.receivable,details.due);
        fprintf(fpp,"%s         %.2f    %.2f      %.2f     %.2f\n",details.name,details.credit,details.paid,details.receivable,details.due);
        printf("Your ID: %s",details.id);
        fprintf(fpp,"Your ID: %s",details.id);

    printf("\nCredit Rate = 3000 taka");
    fprintf(fpp,"\nCredit Rate = 3000 taka");

        credit=credit+details.credit;

    printf("\nTotal credits = %.2f",credit);
    fprintf(fpp,"\nTotal credits = %.2f",credit);

        total=total+details.receivable;

    printf("\nTotal receivable = %.2f\n",total);
    fprintf(fpp,"\nTotal receivable = %.2f\n",total);
    fprintf(fpp,"\n");
    fclose(fpp);

}



